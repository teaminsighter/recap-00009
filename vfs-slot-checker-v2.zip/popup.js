// ============================================================
//  VFS Slot Checker - Popup Script
// ============================================================

const $ = (id) => document.getElementById(id);

const statusDot = $('statusDot');
const statusText = $('statusText');
const statusEmail = $('statusEmail');
const btnSlots = $('btnSlots');
const autoToggle = $('autoToggle');
const intervalInput = $('intervalInput');
const resultBox = $('resultBox');
const lastCheck = $('lastCheck');
const slotsAlert = $('slotsAlert');
const btnTokens = $('btnTokens');
const tokenBox = $('tokenBox');
const tokenCS = $('tokenCS');
const tokenAuth = $('tokenAuth');
const tokenRoute = $('tokenRoute');
const tokenEmail = $('tokenEmail');
const tokenTS = $('tokenTS');
const copiedMsg = $('copiedMsg');
const btnRefreshToken = $('btnRefreshToken');
const btnFetchWithToken = $('btnFetchWithToken');
const fetchResultLabel = $('fetchResultLabel');
const fetchResultBox = $('fetchResultBox');
const btnCustom = $('btnCustom');
const customCallBox = $('customCallBox');
const btnCallSend = $('btnCallSend');
const btnReset = $('btnReset');

// ── Load current state ──

function refreshState() {
    chrome.runtime.sendMessage({ type: 'GET_STATE' }, (state) => {
        if (!state) return;

        // Status indicator
        if (state.ready) {
            statusDot.className = 'status-dot green';
            statusText.textContent = 'Ready';
            btnSlots.disabled = false;
            btnTokens.disabled = false;
        } else if (state.hasRsaKey || state.hasAuth) {
            statusDot.className = 'status-dot yellow';
            statusText.textContent = 'Partially captured - keep browsing VFS';
            btnSlots.disabled = true;
            btnTokens.disabled = true;
        } else {
            statusDot.className = 'status-dot red';
            statusText.textContent = 'Not connected - login to VFS first';
            btnSlots.disabled = true;
            btnTokens.disabled = true;
        }

        // Details
        let details = [];
        if (state.email) details.push(state.email);
        if (state.route) details.push('Route: ' + state.route);
        statusEmail.textContent = details.join(' | ');

        // Auto-check
        autoToggle.checked = state.autoCheck;
        intervalInput.value = state.interval;

        // Last result
        if (state.lastCheck) {
            const time = new Date(state.lastCheck).toLocaleTimeString();
            lastCheck.textContent = 'Last check: ' + time;
        }

        if (state.lastResult) {
            showResult(state.lastResult, state.slotsFound);
        }

        // Slots alert
        if (state.slotsFound) {
            slotsAlert.classList.add('visible');
        } else {
            slotsAlert.classList.remove('visible');
        }
    });
}

function showResult(data, hasSlots) {
    resultBox.classList.add('visible');
    resultBox.classList.remove('slots-found', 'error');

    if (hasSlots) {
        resultBox.classList.add('slots-found');
    }

    resultBox.textContent = JSON.stringify(data, null, 2);
}

function showError(msg) {
    resultBox.classList.add('visible', 'error');
    resultBox.classList.remove('slots-found');
    resultBox.textContent = 'Error: ' + msg;
}

function setLoading(btn, loading) {
    if (loading) {
        btn._origText = btn.textContent;
        btn.textContent = 'Loading...';
        btn.disabled = true;
    } else {
        btn.textContent = btn._origText || btn.textContent;
        btn.disabled = false;
    }
}

// ── Check Slots ──

btnSlots.addEventListener('click', () => {
    setLoading(btnSlots, true);
    chrome.runtime.sendMessage({ type: 'CHECK_SLOTS' }, (result) => {
        setLoading(btnSlots, false);

        if (result?.error) {
            showError(result.error);
            return;
        }

        showResult(result.data, result.hasSlots);
        lastCheck.textContent = 'Last check: ' + new Date().toLocaleTimeString();

        if (result.hasSlots) {
            slotsAlert.classList.add('visible');
        } else {
            slotsAlert.classList.remove('visible');
        }
    });
});

// ── Auto-Check Toggle ──

autoToggle.addEventListener('change', () => {
    chrome.runtime.sendMessage({
        type: 'SET_AUTO_CHECK',
        enabled: autoToggle.checked,
        interval: parseInt(intervalInput.value) || 30
    });
});

intervalInput.addEventListener('change', () => {
    if (autoToggle.checked) {
        chrome.runtime.sendMessage({
            type: 'SET_AUTO_CHECK',
            enabled: true,
            interval: parseInt(intervalInput.value) || 30
        });
    }
});

// ── Show Tokens ──

function fetchAndShowTokens() {
    chrome.runtime.sendMessage({ type: 'GET_TOKENS' }, (result) => {
        if (result?.error) {
            showError(result.error);
            return;
        }

        tokenCS.textContent = result.clientsource;
        tokenAuth.textContent = result.authorize || 'not captured';
        tokenRoute.textContent = result.route || 'not captured';
        tokenEmail.textContent = result.email || 'not captured';
        tokenTS.textContent = result.timestamp;
        tokenBox.classList.add('visible');
    });
}

btnTokens.addEventListener('click', () => {
    if (tokenBox.classList.contains('visible')) {
        tokenBox.classList.remove('visible');
    } else {
        fetchAndShowTokens();
    }
});

btnRefreshToken.addEventListener('click', () => {
    fetchAndShowTokens();
});

// ── Fetch Slots with Fresh Token ──

btnFetchWithToken.addEventListener('click', () => {
    setLoading(btnFetchWithToken, true);
    fetchResultLabel.style.display = 'block';
    fetchResultBox.classList.add('visible');
    fetchResultBox.classList.remove('slots-found', 'error');
    fetchResultBox.textContent = 'Fetching...';

    chrome.runtime.sendMessage({ type: 'FETCH_WITH_TOKEN' }, (result) => {
        setLoading(btnFetchWithToken, false);

        if (result?.error) {
            fetchResultBox.classList.add('error');
            fetchResultBox.textContent = 'Error: ' + result.error;
            return;
        }

        // Update token display with the tokens that were actually used
        tokenCS.textContent = result.tokens.clientsource;
        tokenAuth.textContent = result.tokens.authorize || 'not captured';
        tokenRoute.textContent = result.tokens.route || 'not captured';
        tokenEmail.textContent = result.tokens.email || 'not captured';
        tokenTS.textContent = result.tokens.timestamp;

        // Show API response
        const hasSlots =
            (result.fetch.data?.data && Array.isArray(result.fetch.data.data) && result.fetch.data.data.length > 0) ||
            (result.fetch.data?.slots && Array.isArray(result.fetch.data.slots) && result.fetch.data.slots.length > 0) ||
            (result.fetch.data?.earliestDate);

        fetchResultBox.textContent =
            'HTTP ' + result.fetch.status + '\n\n' +
            JSON.stringify(result.fetch.data, null, 2);

        if (hasSlots) {
            fetchResultBox.classList.add('slots-found');
        }
        if (result.fetch.status >= 400) {
            fetchResultBox.classList.add('error');
        }
    });
});

// Click to copy any token value
function copyTokenValue(el) {
    const text = el.textContent || el.innerText;
    if (!text || text === 'not captured') return;
    navigator.clipboard.writeText(text).then(() => {
        copiedMsg.classList.add('visible');
        setTimeout(() => copiedMsg.classList.remove('visible'), 1500);
    });
}

tokenCS.addEventListener('click', () => copyTokenValue(tokenCS));
tokenAuth.addEventListener('click', () => copyTokenValue(tokenAuth));
tokenRoute.addEventListener('click', () => copyTokenValue(tokenRoute));
tokenEmail.addEventListener('click', () => copyTokenValue(tokenEmail));

// ── Quick Actions ──

function getQaParams() {
    return {
        urn: $('qaUrn').value.trim(),
        centerCode: $('qaCenterCode').value.trim() || 'DAC',
        visaCategory: $('qaVisaCategory').value.trim() || '02',
        date: $('qaDate').value.trim(),
        otp: $('qaOtp').value.trim()
    };
}

function saveQaParams() {
    chrome.storage.local.set({
        qaParams: {
            urn: $('qaUrn').value.trim(),
            centerCode: $('qaCenterCode').value.trim(),
            visaCategory: $('qaVisaCategory').value.trim(),
            date: $('qaDate').value.trim()
        }
    });
}

function loadQaParams() {
    chrome.storage.local.get(['qaParams'], (res) => {
        if (res.qaParams) {
            if (res.qaParams.urn) $('qaUrn').value = res.qaParams.urn;
            if (res.qaParams.centerCode) $('qaCenterCode').value = res.qaParams.centerCode;
            if (res.qaParams.visaCategory) $('qaVisaCategory').value = res.qaParams.visaCategory;
            if (res.qaParams.date) $('qaDate').value = res.qaParams.date;
        }
    });
}

function sendQuickAction(action, btn) {
    const params = getQaParams();
    saveQaParams();

    if (!params.urn && action !== 'application') {
        showError('Enter a URN first');
        return;
    }
    if (action === 'verifyOtp' && !params.otp) {
        showError('Enter the OTP first');
        return;
    }
    if (action === 'timeslot' && !params.date) {
        showError('Enter a date first');
        return;
    }

    setLoading(btn, true);
    chrome.runtime.sendMessage({
        type: 'QUICK_ACTION',
        action,
        params
    }, (result) => {
        setLoading(btn, false);
        if (result?.error) {
            showError(result.error);
            return;
        }
        showResult(result.data, false);
    });
}

$('qaCalendar').addEventListener('click', function() { sendQuickAction('calendar', this); });
$('qaTimeslot').addEventListener('click', function() { sendQuickAction('timeslot', this); });
$('qaSendOtp').addEventListener('click', function() { sendQuickAction('sendOtp', this); });
$('qaVerifyOtp').addEventListener('click', function() { sendQuickAction('verifyOtp', this); });
$('qaFees').addEventListener('click', function() { sendQuickAction('fees', this); });
$('qaMapVas').addEventListener('click', function() { sendQuickAction('mapvas', this); });
$('qaApplication').addEventListener('click', function() { sendQuickAction('application', this); });

// Save params on input change
['qaUrn', 'qaCenterCode', 'qaVisaCategory', 'qaDate'].forEach(id => {
    $(id).addEventListener('change', saveQaParams);
});

// ── Custom API Call ──

btnCustom.addEventListener('click', () => {
    customCallBox.classList.toggle('visible');
});

btnCallSend.addEventListener('click', () => {
    const method = $('callMethod').value;
    const endpoint = $('callEndpoint').value.trim();
    const bodyStr = $('callBody').value.trim();

    if (!endpoint) {
        showError('Enter an endpoint');
        return;
    }

    let body = null;
    if (bodyStr) {
        try {
            body = JSON.parse(bodyStr);
        } catch (e) {
            showError('Invalid JSON body');
            return;
        }
    }

    setLoading(btnCallSend, true);
    chrome.runtime.sendMessage({
        type: 'CUSTOM_CALL',
        method,
        endpoint,
        body
    }, (result) => {
        setLoading(btnCallSend, false);

        if (result?.error) {
            showError(result.error);
            return;
        }

        showResult(result.data, false);
    });
});

// ── Reset ──

btnReset.addEventListener('click', () => {
    if (confirm('Reset all captured data? You will need to login to VFS again.')) {
        chrome.runtime.sendMessage({ type: 'RESET' }, () => {
            resultBox.classList.remove('visible');
            slotsAlert.classList.remove('visible');
            lastCheck.textContent = '';
            refreshState();
        });
    }
});

// ============================================================
//  Visual Calendar & Time Slots
// ============================================================

const calendarDays = $('calendarDays');
const calMonthYear = $('calMonthYear');
const calendarLoading = $('calendarLoading');
const calendarStatus = $('calendarStatus');
const timeslotsSection = $('timeslotsSection');
const timeslotsGrid = $('timeslotsGrid');
const timeslotsDate = $('timeslotsDate');
const timeslotsLoading = $('timeslotsLoading');
const timeslotsEmpty = $('timeslotsEmpty');
const selectedSlotInfo = $('selectedSlotInfo');
const selectedSlotText = $('selectedSlotText');

// Calendar state
let calendarState = {
    currentMonth: new Date().getMonth(),
    currentYear: new Date().getFullYear(),
    availableDates: [],       // Array of available date strings "DD/MM/YYYY"
    selectedDate: null,       // Selected date string
    selectedTime: null,       // Selected time string
    availableSlots: []        // Available time slots for selected date
};

const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June',
                     'July', 'August', 'September', 'October', 'November', 'December'];

// ── Render Calendar Grid ──

function renderCalendar() {
    const year = calendarState.currentYear;
    const month = calendarState.currentMonth;

    calMonthYear.textContent = `${MONTH_NAMES[month]} ${year}`;

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();

    let html = '';

    // Empty cells before first day
    for (let i = 0; i < firstDay; i++) {
        html += '<div class="calendar-day empty"></div>';
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = formatDateDMY(day, month + 1, year);
        const isAvailable = calendarState.availableDates.includes(dateStr);
        const isSelected = calendarState.selectedDate === dateStr;
        const isToday = (day === today.getDate() && month === today.getMonth() && year === today.getFullYear());

        let classes = ['calendar-day', 'current-month'];
        if (isAvailable) classes.push('available');
        if (isSelected) classes.push('selected');
        if (isToday) classes.push('today');

        html += `<div class="${classes.join(' ')}" data-date="${dateStr}" data-day="${day}">${day}</div>`;
    }

    calendarDays.innerHTML = html;

    // Add click handlers to available days
    calendarDays.querySelectorAll('.calendar-day.available').forEach(el => {
        el.addEventListener('click', () => {
            const date = el.dataset.date;
            selectDate(date);
        });
    });
}

function formatDateDMY(day, month, year) {
    return `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`;
}

function parseDateDMY(dateStr) {
    const parts = dateStr.split('/');
    return {
        day: parseInt(parts[0]),
        month: parseInt(parts[1]),
        year: parseInt(parts[2])
    };
}

// ── Load Available Dates from API ──

function loadCalendar() {
    const centerCode = $('qaCenterCode').value.trim() || 'DAC';
    const visaCat = $('qaVisaCategory').value.trim() || '02';
    const urn = $('qaUrn').value.trim();

    calendarLoading.style.display = 'block';
    calendarStatus.textContent = '';
    calendarStatus.className = 'calendar-status';

    // Format the fromDate as DD/MM/YYYY
    const fromDate = formatDateDMY(1, calendarState.currentMonth + 1, calendarState.currentYear);

    chrome.runtime.sendMessage({
        type: 'QUICK_ACTION',
        action: 'calendar',
        params: {
            centerCode: centerCode,
            visaCategory: visaCat,
            urn: urn,
            date: fromDate
        }
    }, (result) => {
        calendarLoading.style.display = 'none';

        if (result?.error) {
            calendarStatus.textContent = 'Error: ' + result.error;
            calendarStatus.className = 'calendar-status error';
            return;
        }

        // Parse available dates from response
        parseAvailableDates(result.data);
        renderCalendar();

        if (calendarState.availableDates.length > 0) {
            calendarStatus.textContent = `${calendarState.availableDates.length} dates available`;
            calendarStatus.className = 'calendar-status success';
        } else {
            calendarStatus.textContent = 'No slots available this month';
            calendarStatus.className = 'calendar-status';
        }
    });
}

function parseAvailableDates(data) {
    calendarState.availableDates = [];

    if (!data) return;

    // Handle different response formats
    let dates = [];

    if (Array.isArray(data)) {
        dates = data;
    } else if (data.data && Array.isArray(data.data)) {
        dates = data.data;
    } else if (data.dates && Array.isArray(data.dates)) {
        dates = data.dates;
    } else if (data.availableDates && Array.isArray(data.availableDates)) {
        dates = data.availableDates;
    } else if (typeof data === 'object') {
        // Try to extract dates from nested structure
        for (const key of Object.keys(data)) {
            if (Array.isArray(data[key])) {
                dates = data[key];
                break;
            }
        }
    }

    // Parse dates to DD/MM/YYYY format
    dates.forEach(date => {
        if (typeof date === 'string') {
            // Already in DD/MM/YYYY
            if (/^\d{2}\/\d{2}\/\d{4}$/.test(date)) {
                calendarState.availableDates.push(date);
            }
            // YYYY-MM-DD format
            else if (/^\d{4}-\d{2}-\d{2}/.test(date)) {
                const parts = date.split('-');
                const formatted = `${parts[2].substring(0, 2)}/${parts[1]}/${parts[0]}`;
                calendarState.availableDates.push(formatted);
            }
        } else if (date && date.date) {
            calendarState.availableDates.push(date.date);
        }
    });
}

// ── Select Date & Load Time Slots ──

function selectDate(dateStr) {
    calendarState.selectedDate = dateStr;
    calendarState.selectedTime = null;
    renderCalendar();
    loadTimeSlots(dateStr);
}

function loadTimeSlots(dateStr) {
    const centerCode = $('qaCenterCode').value.trim() || 'DAC';
    const visaCat = $('qaVisaCategory').value.trim() || '02';
    const urn = $('qaUrn').value.trim();

    timeslotsSection.classList.add('visible');
    timeslotsDate.textContent = dateStr;
    timeslotsLoading.style.display = 'block';
    timeslotsGrid.innerHTML = '';
    timeslotsEmpty.style.display = 'none';
    selectedSlotInfo.classList.remove('visible');

    // Also update the date input field
    $('qaDate').value = dateStr;

    chrome.runtime.sendMessage({
        type: 'QUICK_ACTION',
        action: 'timeslot',
        params: {
            centerCode: centerCode,
            visaCategory: visaCat,
            urn: urn,
            date: dateStr
        }
    }, (result) => {
        timeslotsLoading.style.display = 'none';

        if (result?.error) {
            timeslotsEmpty.textContent = 'Error: ' + result.error;
            timeslotsEmpty.style.display = 'block';
            return;
        }

        // Parse time slots from response
        parseTimeSlots(result.data);
        renderTimeSlots();
    });
}

function parseTimeSlots(data) {
    calendarState.availableSlots = [];

    if (!data) return;

    let slots = [];

    if (Array.isArray(data)) {
        slots = data;
    } else if (data.data && Array.isArray(data.data)) {
        slots = data.data;
    } else if (data.slots && Array.isArray(data.slots)) {
        slots = data.slots;
    } else if (data.timeSlots && Array.isArray(data.timeSlots)) {
        slots = data.timeSlots;
    } else if (typeof data === 'object') {
        for (const key of Object.keys(data)) {
            if (Array.isArray(data[key])) {
                slots = data[key];
                break;
            }
        }
    }

    slots.forEach(slot => {
        if (typeof slot === 'string') {
            calendarState.availableSlots.push(slot);
        } else if (slot && (slot.time || slot.slotTime || slot.slot)) {
            calendarState.availableSlots.push(slot.time || slot.slotTime || slot.slot);
        }
    });
}

function renderTimeSlots() {
    if (calendarState.availableSlots.length === 0) {
        timeslotsEmpty.textContent = 'No time slots available for this date';
        timeslotsEmpty.style.display = 'block';
        timeslotsGrid.innerHTML = '';
        return;
    }

    timeslotsEmpty.style.display = 'none';

    let html = '';
    calendarState.availableSlots.forEach(time => {
        const isSelected = calendarState.selectedTime === time;
        html += `<button class="timeslot-btn ${isSelected ? 'selected' : ''}" data-time="${time}">${time}</button>`;
    });

    timeslotsGrid.innerHTML = html;

    // Add click handlers
    timeslotsGrid.querySelectorAll('.timeslot-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            selectTimeSlot(btn.dataset.time);
        });
    });
}

function selectTimeSlot(time) {
    calendarState.selectedTime = time;
    renderTimeSlots();

    selectedSlotText.textContent = `Selected: ${calendarState.selectedDate} at ${time}`;
    selectedSlotInfo.classList.add('visible');
}

// ── Calendar Navigation ──

$('calPrev').addEventListener('click', () => {
    calendarState.currentMonth--;
    if (calendarState.currentMonth < 0) {
        calendarState.currentMonth = 11;
        calendarState.currentYear--;
    }
    renderCalendar();
    loadCalendar();
});

$('calNext').addEventListener('click', () => {
    calendarState.currentMonth++;
    if (calendarState.currentMonth > 11) {
        calendarState.currentMonth = 0;
        calendarState.currentYear++;
    }
    renderCalendar();
    loadCalendar();
});

$('btnLoadCalendar').addEventListener('click', loadCalendar);
$('btnRefreshCalendar').addEventListener('click', loadCalendar);

// ── Proceed to Booking ──

$('btnProceedBooking').addEventListener('click', () => {
    if (!calendarState.selectedDate || !calendarState.selectedTime) {
        alert('Please select a date and time slot first');
        return;
    }

    // Update the Quick Actions fields
    $('qaDate').value = calendarState.selectedDate;

    // Show a confirmation with the selected slot
    const msg = `Ready to book:\n\nDate: ${calendarState.selectedDate}\nTime: ${calendarState.selectedTime}\n\nNext steps:\n1. Click "Send OTP" to get verification code\n2. Enter OTP and click "Verify OTP"\n3. Complete booking on VFS website`;
    alert(msg);

    // Scroll to quick actions
    $('quickActionsBox').scrollIntoView({ behavior: 'smooth' });
});

// ── Init ──

refreshState();
loadQaParams();
renderCalendar(); // Initial render

// Refresh every 2 seconds while popup is open
setInterval(refreshState, 2000);
